# Schoolcup-portaal – instructies voor Claude Code

## Wat we bouwen
Een webportaal voor de **Verbroedering Schoolcup Zwijndrecht**: een voetbalcompetitie voor lagere scholen (U8–U12) georganiseerd door voetbalclub Verbroedering Zwijndrecht (stamnummer 9428).
Scholen vragen deelname aan, krijgen een login en beheren zelf hun ploegen, spelerskernen en per speeldag de selectie, verantwoordelijke en coaches. De beheerder (TVJO van de club) keurt aanvragen goed, plant de speeldagen, registreert aanwezigheid en uitslagen.

- Het **werkende prototype** staat in `docs/prototype.html`. Open het in een browser: het is de referentie voor schermen, teksten en regels.
- Alle **spelregels en afspraken** staan in `docs/functionele-specificatie.md`. Bij twijfel: die specificatie wint van het prototype.
- Het **werkplan** in fases staat in `docs/werkplan.md`. Werk fase per fase; begin nooit aan een volgende fase zonder dat Tom de vorige getest heeft.

## Over de gebruiker
Tom heeft matige IT-kennis. Leg elke stap uit in eenvoudig Nederlands, zeg precies wat hij moet klikken of typen, en vraag hem te testen voor je verder gaat. Geen jargon zonder uitleg.

## Technische keuzes (niet wijzigen zonder overleg)
- Frontend: Vite + React + TypeScript, geen andere UI-frameworks. Eenvoudige CSS (huisstijl uit het prototype: navy #0A1633, groen #1FA64A, blauw #1F64D6, lettertypes Barlow Condensed en Atkinson Hyperlegible).
- Backend: Supabase (project in EU-regio): Postgres, Auth (e-mail + wachtwoord), Row Level Security, Edge Functions (Deno), pg_cron voor geplande mails.
- Mails: Resend, aangeroepen vanuit Edge Functions. Supabase Auth-mails via custom SMTP van Resend.
- Hosting: statische site op Netlify of Cloudflare Pages (pas in de laatste fase).
- Taal van de interface: Nederlands (Vlaams), datums in nl-BE.

## Beveiliging – harde regels
1. **Geen geheimen in de code of in Git.** De publieke Supabase-sleutel (publishable/anon) mag in `.env.local`. De geheime sleutel (secret/service_role) en de Resend-sleutel staan enkel als Supabase Edge Function secrets (`supabase secrets set`). Vraag Tom nooit om een geheime sleutel in de chat te plakken.
2. **Row Level Security op elke tabel**, zonder uitzondering. Een school ziet en wijzigt enkel haar eigen gegevens. Schrijf voor elke tabel een test die bewijst dat school A niets van school B kan lezen of wijzigen.
3. **Deadlines en limieten in de database afdwingen** (triggers/policies met `now()`), niet enkel in de interface: kernbevriezing, selectiedeadline, max. 25 per kern, max. 8/12 op het wedstrijdblad, ploegdeadline.
4. Beheerdersrechten via een rol in de database (bv. tabel `admins`), nooit via iets wat de browser kan aanpassen.
5. **Enkel fictieve data** tijdens het bouwen (seed-script). Nooit echte namen van kinderen in code, tests, seeds of chat.
6. Minimale gegevens: van kinderen enkel voornaam, naam, geboortejaar, leerjaar. Van volwassenen enkel voornaam, naam, rol, e-mail van de schoolaccount.

## Werkwijze
- Kleine stappen, na elke stap: wat is er veranderd, hoe test Tom het, daarna commit met duidelijke boodschap.
- Databasewijzigingen altijd als migratie in `supabase/migrations/`.
- Houd `docs/werkplan.md` bij: vink afgewerkte onderdelen af.
