# Werkplan – Schoolcup-portaal

Werk fase per fase. Elke fase: Claude Code bouwt, Tom test met de checklist, daarna commit en push.
Kopieer de opdracht van een fase letterlijk in Claude Code.

## Fase 0 – Project opzetten
**Opdracht:** "Lees CLAUDE.md en de documenten in docs/. Zet een Vite + React + TypeScript-project op in deze map, installeer supabase-js en de Supabase CLI, koppel de CLI aan mijn project schoolcup-dev en maak .env.local aan op basis van .env.example. Leg me elke stap uit."
**Testen:** `npm run dev` toont een startpagina in de huisstijl; `.env.local` staat niet in Git.
- [ ] klaar

## Fase 1 – Database en beveiliging
**Opdracht:** "Maak de databasetabellen volgens docs/functionele-specificatie.md als migraties, met Row Level Security op elke tabel, triggers voor de deadlines en limieten, een admins-tabel, en een seed met fictieve scholen en kinderen zoals in het prototype. Schrijf tests die bewijzen dat school A niets van school B ziet of kan wijzigen."
**Testen:** in Supabase › Table Editor staan de tabellen met fictieve data; de tests slagen.
- [ ] klaar

## Fase 2 – Aanvraag, goedkeuring en aanmelden
**Opdracht:** "Bouw de aanvraagpagina, het aanmelden (e-mail + wachtwoord, wachtwoord vergeten) en bij de beheerder de lijst met aanvragen. Goedkeuren roept een Edge Function aan die het account aanmaakt en een uitnodigingsmail stuurt via Resend. Stel Supabase Auth in om via Resend (custom SMTP) te mailen."
**Testen:** aanvraag met je eigen testadres → mail ontvangen → als beheerder goedkeuren → uitnodiging ontvangen → aanmelden.
- [ ] klaar

## Fase 3 – School: ploegen, kern en speeldag
**Opdracht:** "Bouw voor scholen de tabs Overzicht, Ploegen inschrijven, Spelerskern, Speeldag en Schoolgegevens zoals in het prototype, inclusief deadlines, bevriezing, coach-regel en takenlijst."
**Testen:** met twee testscholen; zet tijdelijk een testdatum (vraag Claude Code hoe) om bevriezing en deadlines te controleren.
- [ ] klaar

## Fase 4 – Beheer: planning, aanwezigheid, uitslagen, klassement
**Opdracht:** "Bouw voor de beheerder Scholen, Planning per speeldag (speelschema genereren, per dag herberekenen, klassementswedstrijden), Aanwezigheid met joker/forfait, Uitslagen en Klassementen met de volledige rangschikkingsregels."
**Testen:** schema genereren, uitslagen invullen, controleren dat klassement en forfaits kloppen met het prototype.
- [ ] klaar

## Fase 5 – Finale
**Opdracht:** "Bouw de finale: finalisten na de laatste speeldag, finalepagina enkel voor hen, deadline één week vooraf met vrijgeleide voor nr. 3 (en nr. 4), en de finaleplanning voor de beheerder."
**Testen:** met testdata en testdatums de vrijgeleide uitlokken.
- [ ] klaar

## Fase 6 – Mails, reglement en afwerking
**Opdracht:** "Voeg de geplande herinneringsmails toe met pg_cron, de pagina Reglement & afspraken (ook zonder login), donkere modus, gsm-weergave en toegankelijkheid."
**Testen:** op je gsm alle schermen doorlopen; herinneringsmail manueel uitlokken.
- [ ] klaar

## Fase 7 – Live zetten
**Opdracht:** "Help me de site live te zetten op Netlify of Cloudflare Pages, gekoppeld aan GitHub, met een subdomein van de club. Maak een tweede Supabase-project schoolcup-prod zonder seed-data, doe een beveiligingscontrole en beschrijf hoe we back-ups maken."
**Beslissing vooraf:** Supabase Pro (geen pauze, back-ups) of gratis met dagelijkse activiteit en eigen back-up.
**Testen:** volledige ronde met één echte testschool en fictieve kinderen. Pas na akkoord van de privacyverantwoordelijke echte inschrijvingen.
- [ ] klaar
