# Schoolcup-portaal

Portaal voor de Verbroedering Schoolcup Zwijndrecht. Zie `CLAUDE.md` en `docs/`.
Beheer: Verbroedering Zwijndrecht vzw – stamnummer 9428.
